drop user ISV6 cascade;
create user ISV6 identified by ISV6;
grant dba to ISV6;
grant connect to ISV6;

