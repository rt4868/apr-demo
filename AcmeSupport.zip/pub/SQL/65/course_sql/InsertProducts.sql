INSERT INTO ProductCatalog VALUES ('','Enterprise Web Services','Peter Cruise','Learn to create Web Services.',25.99);
INSERT INTO ProductCatalog VALUES ('','Integration Server for Dummies','Sara Houston','Learn to use the Integration Server.',29.99);
INSERT INTO ProductCatalog VALUES ('','webMethods Workflow for Developers','Sam Parker','Learn to use webMethods Workflow.',39.99);
commit;